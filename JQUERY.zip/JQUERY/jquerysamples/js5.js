$(document).ready(function(){
    $("body").click(attribute);
})
function attribute()
{
   $("input").attr("checked",false);
}