function myFunction(rollNo:number ,name:String,email:string)
{
    console.log(rollNo);
    console.log(name);
    if(email==undefined)
    {
        console.log("email");
    }

}
myFunction(121,"kelvin","dfhsfhda");