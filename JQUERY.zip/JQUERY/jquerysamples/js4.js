$(document).ready(function(){
    $("#btn").click(attribute);
})
function attribute()
{
   $("#btn").attr("disabled",true);
}