class person {

    constructor(public name: string, public age: number) {

    }
    showInfo() {
        console.log( "name  :" +" " +this.name + "age  :" + this.age)
    }
}
class Employee extends person {
    constructor(name, age, public salery: number) {
        super(name, age);
    }
    showInfo() {
        console.log("name   :" + this.name+"  " + "age : " + this.age +"  "+ " salery  :" + this.salery)
    }
}
var per = new person("udhya", 24);
var emp = new Employee("bharath", 54, 66656);


per.showInfo();
emp.showInfo();

