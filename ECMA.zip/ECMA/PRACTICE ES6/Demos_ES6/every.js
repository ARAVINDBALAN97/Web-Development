window.onload=function(){
  document.getElementById("b1").onclick=f;
}

var people = [
  {name: 'Jack', age: 11},
  {name: 'Michael', age: 19}, 
  {name: 'John', age: 12}, 
  {name: 'Ann', age: 19}, 
  {name: 'Elisabeth', age: 18}
]

//function teenager(person) {
  //  return person.age > 10 && person.age < 20
//}

const teenager=(person)=> person.age > 10 && person.age < 20



function f()
{
   //var res=teenager(people); Cannot pass the array like this..
  var res=teenager(people[1]);// This will pass only the first arrayelement
   var everyoneIsTeenager = people.every(teenager) // Each and every element is sent
  console.log(res);
console.log('Everyone is teenager: ', everyoneIsTeenager)
}