window.onload=function()
{
  document.getElementById("btn1").onclick=myFunction;
}

function Employee()
{
    id=111;
    name="XYZ";
this.getId=function()
{
 return this.id;
}
this.setId=function(val)
{
this.id=val;
}
this.getName=function()
{
return this.name;
}
this.setName=function(val)
{
  this.name=val;
}

    this.disp=function(){
        alert("Welcome");
    }
}


function myFunction()
{
  var emp=new Employee();
  emp.setId(1998);
  alert(emp.getId());
  emp.setName("Ram");
  alert(emp.getName());
  emp.disp();
}