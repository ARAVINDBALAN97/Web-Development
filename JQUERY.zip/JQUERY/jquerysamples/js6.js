$(document).ready(function(){
    $("body").click(attribute);
})
function attribute()
{
   $("option").filter(function(index)
   {
       if(index==1)
        {
            return true;
        }
   }).attr("selected","selected");
// $("#box option[value=two]").attr("selected","selected");
}