import { Component } from '@angular/core';

import {ExampleService} from './app.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {
  title = 'serviceSample';
  
  constructor(private _exampleService: ExampleService) {
    }

    clickmethod() {
        this.title = this._exampleService.someMethod();
    }
}
