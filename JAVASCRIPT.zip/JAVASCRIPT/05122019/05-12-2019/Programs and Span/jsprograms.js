window.onload= function()
{
    
document.getElementById("b1").onclick=odd;
document.getElementById("b2").onclick=sum_num;
document.getElementById("b3").onclick=year_check;
document.getElementById("b4").onclick=factorial;
document.getElementById("b5").onclick=star;
document.getElementById("b6").onclick=reverse;
document.getElementById("b7").onclick=add_digits;
document.getElementById("b8").onclick=fibonaci;

}

function sum_num()
{
var i;
var total_sum=0;
    for(i=1;i<=10;i++)
        {
            total_sum=total_sum+i;
            if(i==10)
                {
  document.write(total_sum);
                }
            
        }
    
}
    function odd ()
{
      var i;
for( i=1;i<=25;i++)
    {
        if((i%2)!==0)
            {
document.writeln(i);
            }
        
    }
    

}

function year_check()
{
    var year;
    year=parseInt(prompt("Enter the Year"));
    if((year%4)==0)
        {
          document.writeln("Leap Year");  
        }
        else
            {
                document.writeln("Not Leap Year");
            }
}
        function factorial()
{
    var i,num;
    var fact=1;
    num=parseInt(prompt("Enter the Number"));
    for(i=1;i<=num;i++)
        {
            fact=fact*i;
        }
        document.write(fact);
}

function star()
{
    var i, j ,num;
  num=parseInt(prompt("Enter the Number"));
  for(i=1; i <= num; i++)
   {
     
    for(j=1; j<=i; j++)
   {   if((i%2)==1)
        {
     document.write("*");
        }
    }
     document.write("<br/>");
   }
}

function reverse()
{
     var num , digit, reversed = 0;
     num=parseInt(prompt("Enter the Number"));
        while(num != 0) {
            digit = num % 10;
            reversed = reversed * 10 + digit;
            num =parseInt(num / 10);
        }
        document.write( reversed);
}

function add_digits()
{
     var num,digit, sum = 0;
     n=parseInt(prompt("Enter the number")); 
          
        while (num != 0) 
        { 
            digit=  num % 10; 
            num = parseInt(num/10) ; 
            sum=sum+digit;
        }
        document.write(sum);
}

function fibonaci()
{
    var n , sum=0,t1 = 0, t2 = 1;
        n=parseInt(prompt("Enter the Number"));
        for ( i = 1; i <= n; ++i)
        {
            document.write(t1 + " ");
            t1 = t2;
            t2 = sum;
            sum = t1 + t2;
        }
}


