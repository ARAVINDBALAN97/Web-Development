function myFunction(a1:number ,a2:number):any{

    return a1+a2;

}


var a=myFunction(41,56);
console.log(a);