function myFunction() {
    var inputs = [];
    for (var _i = 0; _i < arguments.length; _i++) {
        inputs[_i] = arguments[_i];
    }
    var i;
    var sum = 0;
    for (i = 0; i < inputs.length; i++) {
        sum += inputs[i];
    }
    console.log(sum);
}
myFunction(10, 16, 4);
