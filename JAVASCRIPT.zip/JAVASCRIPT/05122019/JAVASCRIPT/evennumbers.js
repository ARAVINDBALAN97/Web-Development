window.onload=function()
{
    document.getElementById("btn").onclick=perform;
}

function perform ()
{
    var input=
}