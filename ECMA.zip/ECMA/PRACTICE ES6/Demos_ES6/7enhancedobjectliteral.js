window.onload=function()
{
  document.getElementById("b1").onclick=f;
}
const color = 'red'
const point = {
  x: 5,
  y: 10,
  color,
  toString() {
    return 'X=' + this.x + ', Y=' + this.y + ', color=' + this.color
  },
  [ 'prop_' + 42 ]: 42
}
function f(){
  console.log("The pointx is" + point.x);
    console.log("The pointy is" + point.y);
      console.log("The pointcolor is" + point.color);
console.log('The point is ' + point)
console.log('The dynamic property is ' + point.prop_42)
}