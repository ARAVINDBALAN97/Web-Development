var employee=(function(){
    function  myFunction(name:string,basic:number,allonce:number)
    {
        this.name=name;
        this.basic=basic;
        this.allonce=allonce;
    }

    employee.prototype.salery=function(){
        return this.basic+this.allonce;
    }
    return employee;
}())



var em=new employee("ram",54,89);
var results=em.salery;
console.log(results);


