let array=[1,87,45,76,354,445,92,34,08,54,4];

array .push(23);
console.log(array);

