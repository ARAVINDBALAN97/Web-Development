window.onload=function()
{
   document.getElementById("b1").onclick=check;
   
}
function check()
{
 var x=document.getElementById("t1").value;
 var y=document.getElementsByName("gender").value;
 var radio1=document.getElementById("r1").checked;
 var radio2=document.getElementById("r2").checked;
    if(x=="")
    {
        document.getElementById("s1").innerText="Name is Empty";
    }
    else if(radio1==false && radio2==false)
    {
            document.getElementById("s2").innerText="Gender is Empty"; 
    }
    else 
        {  
            var r=confirm("Do You Want to Save..?");
            if(r==true)
                alert("Saved");
            else
                alert("Not Saved");

        }   
   

}
