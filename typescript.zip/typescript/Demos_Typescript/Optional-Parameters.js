function myFunction(rollNo, name, email) {
    console.log(rollNo);
    console.log(name);
    if (email == undefined) {
        console.log("email");
    }
}
myFunction(121, "kelvin", "dfhsfhda");
