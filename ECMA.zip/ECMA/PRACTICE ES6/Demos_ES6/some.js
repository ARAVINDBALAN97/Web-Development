var people = [
  {name: 'Jack', age: 50},
  {name: 'Michael', age: 99}, 
  {name: 'John', age: 40}, 
  {name: 'Ann', age: 79}, 
  {name: 'Elisabeth', age:66}
]

function teenager(person) {
    return person.age > 10 && person.age < 20
}

var thereAreTeenagers = people.some(teenager)

console.log('There are teenagers:', thereAreTeenagers)