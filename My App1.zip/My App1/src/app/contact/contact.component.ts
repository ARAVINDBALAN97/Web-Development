import {Component} from '@angular/core';

@Component({
    selector: 'app-contact',
    template: `<h1>{{contact}}</h1>`
})
export class ContactComponent {
    contact : string;
    constructor(){
        this.contact = "Welcome to contact page"
    };
};