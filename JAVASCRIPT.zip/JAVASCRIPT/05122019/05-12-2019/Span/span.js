window.onload=validate;
function validate()
{
    document.getElementById("b1").onclick=test;

}

function test()
{ 
   
    if(document.getElementById("t1").value == "")
        {
           document.getElementById("s1").innerText="Not Filled";
        }
       
}
