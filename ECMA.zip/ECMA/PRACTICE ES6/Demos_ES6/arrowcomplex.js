window.onload=function(){
  document.getElementById("b1").onclick=f;
}


function f(){
var array = [1, 2, 3, 4]

const sum = (acc, value) => {
  const result = acc + value
  console.log(acc, ' plus ', value, ' is ', result)
  return result
}

var sumOfArrayElements = array.reduce(sum);
console.log(sumOfArrayElements);
}