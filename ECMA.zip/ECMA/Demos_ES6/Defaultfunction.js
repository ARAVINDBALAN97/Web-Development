window.onload=function(){
  document.getElementById("b1").onclick=multiply;
}

function multiply(a, b = 1) {
  return a * b;
}
console.log(multiply(5, 2));
console.log(multiply(5));
