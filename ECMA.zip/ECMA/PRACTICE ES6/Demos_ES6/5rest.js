window.onload=function()
{
    document.getElementById("b1").onclick=f;
}

function f()
{
var array = ['red', 'blue', 'green']

var copyOfArray = [...array]
array
console.log('Copy of', array, 'is', copyOfArray)
console.log('Are', array, 'and', copyOfArray, 'same?', array === copyOfArray)
}