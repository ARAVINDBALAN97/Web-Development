window.onload=validate;
function validate()
{
    document.getElementById("button").onclick=details;
}
function details()
{
    var a=/^\w{10,15}$/;
    var b=document.getElementById("name").value;
    var c=document.getElementById("age").value;
    var d=document.getElementById("mobile").value;
    var e=document.getElementById("date").value;
    var mobpattern=/^[6789]\d{9}$/;
    var agepattern=/^[1-99]\d$/;
    var date=/^\d{1,2}(\/|\.|\-)\d{1,2}\1\d{4}$/;
    document.getElementById("sp1").innerHTML="";
    document.getElementById("sp2").innerHTML="";
    document.getElementById("sp3").innerHTML="";
    document.getElementById("sp4").innerHTML="";
    if(b=="" && c=="" && d=="" && e=="")
        {
            document.getElementById("sp1").innerHTML="username is not mentioned";
            document.getElementById("sp2").innerHTML="age is not mentioned";
            document.getElementById("sp3").innerHTML="mobile is not mentioned";
            document.getElementById("sp4").innerHTML="date is not mentioned";
        }
    else if(a.test(b)==false)
        {
            document.getElementById("sp1").innerHTML="username is not in correct";
          //  return false;
        }
     else if(agepattern.test(c)==false)
        {
            document.getElementById("sp2").innerHTML="age is not in correct";
            return false;
        }
        else if(mobpattern.test(d)==false)
        {
            document.getElementById("sp3").innerHTML="mobile is not in correct";
            return false;
        }
        else if(date.test(e)==false)
        {
            document.getElementById("sp4").innerHTML="date is not in correct";
            return false;
        }
        else {
             var r=confirm("are you sure to submit");
                    if(r==true)
                        {
                            alert("saved");
                        }
                        else
                            {
                                alert("not saved");
                            }
        }


     }
        
        
        
