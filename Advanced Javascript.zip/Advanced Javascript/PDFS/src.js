window.onload=function()
{
    document.getElementById("btn").onclick=myfunction;
}
function foo(x)
{
var tmp =3;
return function (y)
{
    alert (x+y(++temp));
}
}
function myfunction ()
{
    var bar = foo(2);
    bar(10);
}