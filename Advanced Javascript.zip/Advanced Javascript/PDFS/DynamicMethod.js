window.onload=function()
{
  document.getElementById("btn1").onclick=myFunction;
}
String.prototype.myReverse=function()
{
    for(var i=this.length-1;i>=0;i--)
    {
        document.write(this.charAt(i));
    }
}


function myFunction()
{
  var name="Welcome";
  name.myReverse();
}