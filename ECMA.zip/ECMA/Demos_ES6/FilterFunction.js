window.onload = function () {
    document.getElementById("btn1").onclick = filterEx;
}

const words = ['spray', 'limit', 'elite', 'exuberant', 'destruction', 'present'];


function filterEx() {
    const result = words.filter(word => word.length > 6);
    console.log(result);
}
