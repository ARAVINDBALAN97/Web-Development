window.onload=function()
{
    document.getElementById("b1").onclick=validate;
}

function validate()
{ 
    var uname=document.getElementById("t1").value;
    var dob=document.getElementById("t2").value;
    var mobile=document.getElementById("t3").value;
    var password=document.getElementById("t4").value;

     var nameptn=/^[a-zA-Z]\w{5,10}$/;
     var dobptn=/^\d{1,2}(\-|\/|\.)\d{1,2}\1\d{4}$/;
     var mobileptn=/^(6|7|8|9)\d{9}$/;
     var passwordptn=/^\w{8}$/;
if(uname==""&&dob==""&&mobile==""&&password=="")
    {
 document.getElementById("s1").innerText="*Please Fill This Field";
 document.getElementById("s2").innerText="*Please Fill This Field";
 document.getElementById("s3").innerText="*Please Fill This Field";
 document.getElementById("s4").innerText="*Please Fill This Field";
    }
   else if( nameptn.test(uname)==false)
    {
   document.getElementById("s1").innerText="Match The Following Name must be contain 5-10 Characters only";
   return false;
    }

 else if( dobptn.test(dob)==false)
    {
   document.getElementById("s2").innerText="Match The Following DOB mm-dd-yyyy or mm/dd/yyyy or mm.dd.yyyy";
   return false;
 }

else if( mobileptn.test(mobile)==false)
    {
   document.getElementById("s3").innerText="Match The Following Mobile must be contain 10 numbers only";
   return false;
    }
else if( passwordptn.test(password)==false)
    {
   document.getElementById("s4").innerText="Match The Following Password  must be contain 8 Alphanumeric characters and _ only ";
   return false;
    }

else
    {
alert("Success");
    }
      




}
