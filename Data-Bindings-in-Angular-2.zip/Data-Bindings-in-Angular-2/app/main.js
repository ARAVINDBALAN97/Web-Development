"use strict";
var platform_browser_dynamic_1 = require('@angular/platform-browser-dynamic');
var Module_1 = require('./Module');
platform_browser_dynamic_1.platformBrowserDynamic().bootstrapModule(Module_1.AppModule);
//# sourceMappingURL=main.js.map