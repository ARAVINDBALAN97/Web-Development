function printBasicInfo({firstName, secondName, profession}) {
	console.log(firstName + ' ' + secondName + ' - ' + profession)
}

function printBasicInfo2(per) {
	console.log(per.firstName + ' ' + per.secondName + ' - ' + per.profession + ' - ' + per.age)
}

var person = {
  firstName: 'John',
  secondName: 'Smith',
  age: 33,
  children: 3,
  profession: 'teacher'
}

printBasicInfo(person)