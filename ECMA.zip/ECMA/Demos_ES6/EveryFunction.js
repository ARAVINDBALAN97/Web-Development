window.onload = function () {
  document.getElementById("btn1").onclick = everyEx;
}
const array = [1, 30, 39, 29, 10, 13];
const valueLessThan = (currentValue) => currentValue < 40;
function everyEx() {
  var rest = valueLessThan(array[1]);
  var eveyNumberInArray = array.every(valueLessThan)
  console.log(rest);
  console.log('Everyone is Value: ', eveyNumberInArray)
}

