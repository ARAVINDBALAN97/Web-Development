
window.onload=function()
{
    document.getElementById("b1").onclick=f;
}

var array = [1, 2, 3, 4]

const sum = (acc, value) =>  acc + value;

const product = (acc, value) => acc * value

function f()
{
var sumOfArrayElements = array.reduce(sum,0)
var productOfArrayElements = array.reduce(product,1)
console.log(sumOfArrayElements);
console.log(productOfArrayElements);
}