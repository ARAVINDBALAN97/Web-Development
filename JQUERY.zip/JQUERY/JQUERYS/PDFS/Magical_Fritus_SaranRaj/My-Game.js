﻿
$(document).ready(function () {
    $(".Button_Click").click(Click_Count);
    $("#Ok_Button").click(function () { window.location="First_Page.htm" });
});

var count = 0;

function Click_Count() {
    
         var Button_val = $(this).val();
         var First_Set_Elements = $("#First_Page_div1 > img");
         var Second_Set_Elements = $("#First_Page_div2 > img");
         var Third_Set_Elements = $("#First_Page_div3 > img");

         if (Button_val == "Set1") {
             $(".imgtd").fadeOut(500);
                        
             var Rearrange1 = jQuery.makeArray(Second_Set_Elements);
             var Rearrange2 = jQuery.makeArray(First_Set_Elements);
             var Rearrange3 = jQuery.makeArray(Third_Set_Elements);
             
             $("#First_Page_div1").empty();
             $("#First_Page_div2").empty();
             $("#First_Page_div3").empty();
             
         }
         else if (Button_val == "Set2") {
             $(".imgtd").fadeOut(500);
           
             var Rearrange1 = jQuery.makeArray(First_Set_Elements);
             var Rearrange2 = jQuery.makeArray(Second_Set_Elements);
             var Rearrange3 = jQuery.makeArray(Third_Set_Elements);
            
             $("#First_Page_div1").empty();
             $("#First_Page_div2").empty();
             $("#First_Page_div3").empty();
             
         }
         else if (Button_val == "Set3") {
             $(".imgtd").fadeOut(500);
            
             var Rearrange1 = jQuery.makeArray(First_Set_Elements);
             var Rearrange2 = jQuery.makeArray(Third_Set_Elements);
             var Rearrange3 = jQuery.makeArray(Second_Set_Elements);

             $("#First_Page_div1").empty();
             $("#First_Page_div2").empty();
             $("#First_Page_div3").empty();
            
         } 
     
    

    

    

    $(Rearrange1[0]).appendTo(First_Page_div1);
    $(Rearrange1[3]).appendTo(First_Page_div1);
    $(Rearrange1[6]).appendTo(First_Page_div1);
    $(Rearrange2[2]).appendTo(First_Page_div1);
    $(Rearrange2[5]).appendTo(First_Page_div1);
    $(Rearrange3[1]).appendTo(First_Page_div1);
    $(Rearrange3[4]).appendTo(First_Page_div1);

    $(Rearrange1[1]).appendTo(First_Page_div2);
    $(Rearrange1[4]).appendTo(First_Page_div2);
    $(Rearrange2[0]).appendTo(First_Page_div2);
    $(Rearrange2[3]).appendTo(First_Page_div2);
    $(Rearrange2[6]).appendTo(First_Page_div2);
    $(Rearrange3[2]).appendTo(First_Page_div2);
    $(Rearrange3[5]).appendTo(First_Page_div2);

    $(Rearrange1[2]).appendTo(First_Page_div3);
    $(Rearrange1[5]).appendTo(First_Page_div3);
    $(Rearrange2[1]).appendTo(First_Page_div3);
    $(Rearrange2[4]).appendTo(First_Page_div3);
    $(Rearrange3[0]).appendTo(First_Page_div3);
    $(Rearrange3[3]).appendTo(First_Page_div3);
    $(Rearrange3[6]).appendTo(First_Page_div3);
    $(".imgtd").fadeIn(500);




    if (count == 2) {
       
        $("#Arrangement1").empty();



        $("#Arrangement1").html('<center><h1 id="Header">Your Selection is !</h1><div id="Result"><div>');


      
        $(Rearrange2[3]).appendTo($("#Result"));


    }
  
count ++;



}



