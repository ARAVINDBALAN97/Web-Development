window.onload=function()
{
    document.getElementById("btn1").onclick=forEachloop;
} 
const items = [10,20,30,50,60]
function forEachloop(val) {
  console.log(val)
}

  items.forEach(forEachloop)