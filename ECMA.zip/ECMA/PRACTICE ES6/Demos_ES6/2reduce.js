window.onload=function()
{
  document.getElementById("b1").onclick=f;
}
var array = [1, 2, 3, 4]

function sum(acc, value) {
  return acc + value
}

function product(acc, value) {
  return acc * value
}

function f()
{
var sumOfArrayElements = array.reduce(sum,0)
var productOfArrayElements = array.reduce(product,1)

console.log('Sum of', array, 'is', sumOfArrayElements)
console.log('Product of', array, 'is', productOfArrayElements)
}