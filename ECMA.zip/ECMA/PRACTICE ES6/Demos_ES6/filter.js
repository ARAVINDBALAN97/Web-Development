window.onload=function(){
    document.getElementById("b1").onclick=f;
}

var values = [1, 60, 34, 30, 5, 25]

function lessThan20(val) {
    return val < 20
}

function f()
{
//var valuesLessThan20 = values.every(lessThan20) returns true or false by checking every 
//value in the array against the condition
var valuesLessThan20 = values.filter(lessThan20) // returns the value which macthes the condition
console.log(valuesLessThan20)
}
