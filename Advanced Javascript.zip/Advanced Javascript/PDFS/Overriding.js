window.onload = myFunction;
        function Person (vId, vName) {
            this.Id = vId;
            this.Name = vName;
        };
 
        Person.prototype.Display = function () {
            alert("Id=" + this.Id.toString() +
                    ", Name=" + this.Name);
        }
        Emp.prototype = new Person();
        function Emp(vId, vName, vOfficeMail) 
        {
            Person.call(this, vId, vName)
            this.OfficeEmail = vOfficeMail;
        };
        Emp.prototype.Display = function () {
            Person.prototype.Display.call(this);
            alert(" OfficeMail=" + this.OfficeEmail);
        }
        function myFunction() {
            var oEmp = new Emp(1001, "Jag", "a@a.com"); 
            oEmp.Display();
            var oPerson = new Person(1002, "Chat"); 
            oPerson.Display();   
        }
 
 
