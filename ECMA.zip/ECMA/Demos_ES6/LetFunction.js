window.onload=function()
{
  document.getElementById("btn1").onclick=letEx;
}
function letEx() {
 var a = 1;
let b = 2;

if (a === 1) {
  var a = 11; 
  let b = 22; 

  console.log(a);  
  console.log(b);
} 
console.log(a);
console.log(b);
}

