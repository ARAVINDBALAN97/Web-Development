
var numbers = [1, 4, 9];

function squareRoot(val){
    return val.Math.sqrt()
}
var squareofrootsnumbers = numbers.map(squareRoot); 

console.log("roots is : " + roots ); 