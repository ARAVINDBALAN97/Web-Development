function myfunction(name, id, saluation) {
    var otherInfo = [];
    for (var _i = 3; _i < arguments.length; _i++) {
        otherInfo[_i - 3] = arguments[_i];
    }
    var addAlldatas;
    addAlldatas = saluation + " " + name + " " + id + " \addmessange:";
    for (var index in otherInfo) {
        addAlldatas += otherInfo[index];
    }
    console.log(addAlldatas);
    console.log("welcome");
}
myfunction("siva", 25, "mr", "salem", "kallupalyama", "vaiyappamalai");
