window.onload= function()
{
document.getElementById("txt1").onblur=validate;
document.getElementById("btn1").onclick=complete;
}

function validate ()
{     
    var text=document.getElementById("txt1").value;
    document.getElementById("spn1").innerHTML=text;
   
    
}
function complete()
{
  document.getElementById("spn1").innerHTML="Clicked";

}