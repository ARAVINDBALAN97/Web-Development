var count=30;
var t;
function timemsg(){
t=setTimeout("alertmsg()",1000);
}

function alertmsg(){
document.getElementById('p1').innerHTML=count;
count=count-1;
if(count>-1)
timemsg();
else{

alert("time out");
}
}

function stopcount()
{
clearTimeout(t);
}
function newgame()
{
window.location.href="home.html";
}