var colors = ['red', 'green', 'blue']

function print(val) {
  console.log(val)
}

colors.forEach(print)