function Calculator()
{
      var  d=document.getElementById("p1").innerText;


       if(d==0)
      {
      alert("times ups");
       }

else
{
     var dynamicid=window.event.srcElement.id;
     var  dyid=document.getElementById(dynamicid).value;
    document.getElementById("se").innerText=document.getElementById('se').innerText+dyid ;
}
     
}
 function Result()
  {
   
   document.getElementById("total").value=eval(document.getElementById("total").value);
   return true;
   }
  