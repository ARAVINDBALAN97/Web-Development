window.onload=function()
{
  document.getElementById("b1").onclick=f;
}
var people = [
  {name: 'Jack', age: 11},
  {name: 'Michael', age: 19}, 
  {name: 'John', age: 40}, 
  {name: 'Ann', age: 19}, 
  {name: 'Elisabeth', age: 16}
]

function teenager(person) {
    return person.age > 10 && person.age < 20
}

function f()
{
//var Teenagerslist= people.filter(teenager)
//console.log(Teenagerslist)
var firstTeenager = people.find(teenager)
console.log('First found teenager:', firstTeenager.name)
}