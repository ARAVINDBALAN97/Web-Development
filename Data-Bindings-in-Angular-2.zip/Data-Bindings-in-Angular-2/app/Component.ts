import { Component } from '@angular/core';
@Component({
  selector: 'student-app',
  template: '<student-form></student-form>'
})
export class AppComponent { }
