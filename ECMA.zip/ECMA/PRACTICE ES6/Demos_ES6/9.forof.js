window.onload=function()
{
    document.getElementById("b1").onclick=f;
}


function f()
{
let iterable = [10, 20, 30];

for (let value of iterable) {
  value += 1;
  console.log(value);
}
}
