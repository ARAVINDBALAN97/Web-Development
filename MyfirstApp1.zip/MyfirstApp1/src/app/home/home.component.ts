import {Component} from '@angular/core';

@Component({
    selector: 'app-home',
    template: `<h1>{{welcome}}</h1><input type="button" id="b1" (click)="disp()"/>`
})
export class HomeComponent {
    welcome : string;
    constructor(){
        this.welcome = "Welcome to home page"
    };
   disp()
   {
              alert("welcome");
   }
};