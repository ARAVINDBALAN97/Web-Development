import {Component} from '@angular/core';

@Component({
    selector: 'app-info',
    template: `<h1>{{info}}</h1>`
})
export class InfoComponent {
    info : string;
    constructor(){
        this.info = "250987654"
    };
};