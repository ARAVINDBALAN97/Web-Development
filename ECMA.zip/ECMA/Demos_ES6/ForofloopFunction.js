window.onload=function()
{
    document.getElementById("btn1").onclick=forOf;
} 

const array = ['Aravind', 'Arun', 'Ashok'];

function forOf()
{

for (const elements of array) {
  console.log(elements);
}
}
