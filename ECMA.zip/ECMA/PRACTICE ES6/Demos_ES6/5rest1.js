
window.onload=function(){
  document.getElementById("b1").onclick=f;
}


function printColors(first, second, third, ...others) {
  console.log('Top three colors are ' + first + ', ' + second + ' and ' + third + '. Others are: ' + others)
}

function f()
{
printColors('yellow', 'blue', 'orange', 'white', 'black')
}