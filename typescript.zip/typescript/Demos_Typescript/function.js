function myFunction(a1, a2) {
    return a1 + a2;
}
var a = myFunction(41, 56);
console.log(a);
