$(document).ready(function(){
    $("#b1").click(function(){
       $("#d1").css("background-color", "green")
    })
})


$(document).ready(function(){
    $("#b2").click(function(){
       $("#s1").css("background-color", "yellow")
    })
})

$(document).ready(function(){
    $("#b3").click(function(){
      $("div").filter("#fd2").css('background-color', 'blue')
    })
})

$(document).ready(function(){
    $("#b5").click(function(){
      $("#b4").attr("disabled",true)
    })
})


$(document).ready(function(){
    $("#b6").click(function(){
     $("input:checkbox[name=vehicle]").attr("checked",false)
    })
})

$(document).ready(function(){
    $("#b7").click(function(){
      $("#sel1 option[value=2]").attr("selected","selected")
    })
})

$(document).ready(function(){
    $("#b8").click(function(){
       $("#div1").css({height:100, width:200})
    })
})



$(document).ready(function(){
    $("#b9").click(function(){
        $("#target").empty()
    })
})


$(document).ready(function(){
$("#b10").click(function(){
 $("#divani").animate({height:"300px",width:"200px"},1500)
})

})
$(document).ready(function(){
    $("#b11").click(function(){
         $(".odd").css('background-color', 'blue')
         $(".even").css('background-color', 'yellow')
    })
})

 $(document).ready(function(){
    $("#b12").click(function(){
  $("div:empty").remove()
    })

  })

  $(document).ready(function(){
    $("#b13").click(function(){
 $("td").each(function(){
  $cell = $(this);
if(parseInt($cell.text()) > 10){
     $cell.css("background-color", "red");
}
})
    })

  })