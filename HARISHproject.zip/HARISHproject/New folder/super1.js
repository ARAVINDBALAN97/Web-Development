window.onload=validate;
function validate()
{
    document.getElementById("button2").onclick=valid;

   
}
function valid()
{
    var id=document.getElementById("Eid").value;
    var value=document.getElementById("Ename").value;
    var pattern=/^[a-zA-Z]+$/;
    if(id<1)
    {
        document.getElementById("s2").innerHTML="please enter valid input";

    }
    else if(id>0)
    {
        document.getElementById("s2").innerHTML="";
    }
    if(value=="")
    {
        document.getElementById("s1").innerHTML="name should enter";

    }
    else if(pattern.test(value)==false)
    {
            document.getElementById("s1").innerHTML="name should have only alphapet";
             return false;
    }
    else if(pattern.test(value)==true)
    {
            document.getElementById("s1").innerHTML="";
             return true;
    }
}
