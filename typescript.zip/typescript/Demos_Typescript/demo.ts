function myfunction(name:string,id:number,saluation:string,...otherInfo:string[])
{
   var addAlldatas:string;
   addAlldatas=saluation+" "+ name +" "+id+" \addmessange:";



   for(var index in otherInfo){
       addAlldatas+=otherInfo[index];
   }
   console.log(addAlldatas);


console.log("welcome");

}

myfunction("siva",25,"mr","salem","kallupalyama","vaiyappamalai");
