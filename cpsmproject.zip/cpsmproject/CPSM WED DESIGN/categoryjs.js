window.onload=function()
{
   document.getElementById("btn1").onclick=patternvalidate;
   document.getElementById("btn2").onclick=validtionforcancel;
}

function patternvalidate()
{
   var ctgname=document.getElementById("txt1").value;
   var ctgdesc=document.getElementById("txt01").value;

   var ctgptn=/^[a-zA-Z]+([\.]?[a-zA-Z]+)?$/;
   var ctgdescptn=/^[a-zA-Z]+([\.|\s]?[a-zA-Z]+)?$/;

   if(ctgptn.test(ctgname)==false && ctgdescptn.test(ctgdesc)==false)
    {
        alert("Please enter suitable character");
       // return false;
    }
}
   function validtionforcancel()
        {
            document.getElementById("frm1").reset;
        }