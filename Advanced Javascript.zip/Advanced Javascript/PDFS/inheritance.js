window.onload=function()
{
  document.getElementById("btn1").onclick=myFunction;
}
function Parentclass(){}
Parentclass.prototype.pid=111;
Parentclass.prototype.pmethod=function()
{
    alert(this.pid);
}

function Childclass(){}
Childclass.prototype=new Parentclass();
Childclass.prototype.constructor=Childclass;

Childclass.prototype.cid=222;
Childclass.prototype.cmethod=function()
{
    alert(this.cid);
}

function myFunction()
{
  var pobj= new Parentclass();
  pobj.pmethod();
  var cobj= new Childclass();
  cobj.cmethod();
  cobj.pmethod();

cobj.constructor.prototype.newchildmeth=function()
{
    alert("New Meth");
}
cobj.newchildmeth();
}
