function myFunction(...inputs:number[])
{
    var i;
  var sum=0;
    for(i=0;i<inputs.length;i++)
    {
sum+=inputs[i];

    }
    console.log(sum);

}

myFunction(10,16,4);