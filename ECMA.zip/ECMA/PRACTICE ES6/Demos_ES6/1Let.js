window.onload=function()
{
  document.getElementById("b1").onclick=f;
}
function f() {
 
  var x = 1
  // console.log('xvv outside of block scope is', x)
  //let is blocked scope
  //var is local scope (within a function acts like a local variable)
  let y = 2
  const z = 3
  {
    var x = 100
    let y = 200
    const z = 300
    console.log('x in block scope is', x)
    console.log('y in block scope is', y)
    console.log('z in block scope is', z)
  }
  console.log('x outside of block scope is', x)
  console.log('y outside of block scope is', y)
  console.log('z outside of block scope is', z)
}


