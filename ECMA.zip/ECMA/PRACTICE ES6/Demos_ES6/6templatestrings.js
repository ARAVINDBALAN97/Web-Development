window.onload=function()
{
  document.getElementById("b1").onclick=f;
}

function hello(firstName, lastName) {
  return `Good morning ${firstName} ${lastName}! 
How are you?`
}

function f()
{

console.log(hello('Jane', 'Kowalski'))
}