$(document).ready(function(){
    $("body").click(change);
})
function change()
{
    $("div").filter(function(index){
        if(index==1){
            return true;
        }
    }).css("background-color","green");
}