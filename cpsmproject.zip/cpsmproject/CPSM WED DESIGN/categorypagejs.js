window.onload=function()
{
 // document.getElementById("btn1").onclick=validate;
  document.getElementById("btn2").onclick=validtionforcancel;
   document.getElementById("btn1").onclick=patternvalidation;

}

function validate()
{
  var textbox1=document.getElementById("txt1").value;
  var textarea1=document.getElementById("txt01").value;


  if((textbox1=="" && textarea1==""))
    {
        alert("Enter the category and description");
    }
   else if((textbox1=="" || textarea1==""))
    {
        alert("Enter the category and description");
    }
    else 
        {
            var r=confirm("do you want to save ?")

            if (r==true)
                {
                    alert("Saved");
                }
                else
                    {
                        alert ("not saved");
                }
        }
}
    function validtionforcancel()
        {
            document.getElementById("frm1").reset;
        }
        function patternvalidation()
        {
            var txtptn=document.getElementById("txt1").value;
            var txtareaptn=document.getElementById("txt01").value;

            var txptnval1=/^\d{2,5}$/;

            if(txptnval1.test(txtptn)==false)
                {
                    alert("please enter suitable characters");
                    return false;
                }
            
        }
    