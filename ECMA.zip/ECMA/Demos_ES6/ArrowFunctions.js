
window.onload=function()
{
    document.getElementById("btn1").onclick=simpleArrow;
}

const materials = [
  'Hydrogen',
  'Helium',
  'Lithium',
  'Beryllium'
];
function simpleArrow()
{
console.log(materials.map(material => material.length));
}



