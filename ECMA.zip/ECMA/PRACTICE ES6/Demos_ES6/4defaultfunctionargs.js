window.onload=function(){
  document.getElementById("b1").onclick=f;
}


function sort(arr = [], direction = 'ascending') {
  console.log('I\'m going to sort the array', arr, direction)
}
function f()
{
sort([1, 2, 3]);
sort([1, 2, 3], 'descending');
}